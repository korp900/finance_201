-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Апр 14 2021 г., 10:38
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `f92553mg_0201`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--
-- Создание: Апр 12 2021 г., 17:15
-- Последнее обновление: Апр 12 2021 г., 17:15
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `user_id` int(10) NOT NULL,
  `account_id` bigint(15) NOT NULL,
  `user_account` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`user_id`, `account_id`, `user_account`) VALUES
(1, 1, 'наличные'),
(1, 2, 'карта');

-- --------------------------------------------------------

--
-- Структура таблицы `blog`
--
-- Создание: Мар 26 2021 г., 06:20
--

DROP TABLE IF EXISTS `blog`;
CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` varchar(90) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `author` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `blog`
--

INSERT INTO `blog` (`id`, `title`, `text`, `author`, `date_added`) VALUES
(1, 'статья 1', 'JavaScript обычно используется как встраиваемый язык для программного доступа к объектам приложений. Наиболее широкое применение находит в браузерах как язык сценариев для придания интерактивности веб-страницам.', 'Иван', '2021-03-26 06:29:48'),
(2, 'статья 2', 'На JavaScript оказали влияние многие языки, при разработке была цель сделать язык похожим на Java. Языком JavaScript не владеет какая-либо компания или организация, что отличает его от ряда языков программирования, используемых в веб-разработке.', 'Николай', '2021-03-26 06:29:48'),
(3, 'статья 3', 'Название «JavaScript» является зарегистрированным товарным знаком корпорации Oracle в США.', 'Матвей', '2021-03-26 06:29:48');

-- --------------------------------------------------------

--
-- Структура таблицы `cashflow`
--
-- Создание: Апр 12 2021 г., 15:40
--

DROP TABLE IF EXISTS `cashflow`;
CREATE TABLE `cashflow` (
  `cf_id` int(1) NOT NULL,
  `cf_orientation` varchar(11) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cashflow`
--

INSERT INTO `cashflow` (`cf_id`, `cf_orientation`) VALUES
(1, 'поступление'),
(2, 'платеж');

-- --------------------------------------------------------

--
-- Структура таблицы `cashflow_names`
--
-- Создание: Апр 12 2021 г., 17:13
-- Последнее обновление: Апр 12 2021 г., 17:13
--

DROP TABLE IF EXISTS `cashflow_names`;
CREATE TABLE `cashflow_names` (
  `user_id` int(10) NOT NULL,
  `cf_id` int(1) NOT NULL,
  `cf_name_id` bigint(15) NOT NULL,
  `cf_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cashflow_names`
--

INSERT INTO `cashflow_names` (`user_id`, `cf_id`, `cf_name_id`, `cf_name`) VALUES
(1, 1, 1, 'зарплата'),
(1, 1, 2, 'стипендия'),
(1, 2, 3, 'продукты'),
(1, 2, 4, 'кафе');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--
-- Создание: Апр 09 2021 г., 20:51
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `role_id` int(1) NOT NULL,
  `user_role` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Роли пользователей';

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`role_id`, `user_role`) VALUES
(1, 'Администратор'),
(2, 'Модератор'),
(3, 'Пользователь');

-- --------------------------------------------------------

--
-- Структура таблицы `transactions`
--
-- Создание: Апр 12 2021 г., 16:49
-- Последнее обновление: Апр 12 2021 г., 16:52
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `user_id` int(10) NOT NULL,
  `transaction_id` bigint(20) NOT NULL,
  `transaction_time` datetime NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `account_id` bigint(15) NOT NULL,
  `cf_id` int(1) NOT NULL,
  `cf_name_id` bigint(15) NOT NULL,
  `amount` decimal(17,2) NOT NULL,
  `comment` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `transactions`
--

INSERT INTO `transactions` (`user_id`, `transaction_id`, `transaction_time`, `event_date`, `event_time`, `account_id`, `cf_id`, `cf_name_id`, `amount`, `comment`) VALUES
(1, 1, '2021-04-07 19:00:00', '2021-04-12', '15:00:00', 1, 2, 3, '-1400.00', 'Магнит'),
(1, 2, '2021-04-07 20:00:00', '2021-04-07', '10:00:00', 2, 1, 1, '20000.00', 'аванс');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Апр 09 2021 г., 19:50
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `lastname` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `email` varchar(90) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `pass` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `lastname`, `email`, `pass`) VALUES
(1, 'Алла', 'Иванова', '1@mail.ru', '$2y$10$SSXH49vD7vdB5R5nWePlJe9g13D02Uvazjx7cqC5kCx14PqEbbALW');

-- --------------------------------------------------------

--
-- Структура таблицы `users_lf`
--
-- Создание: Апр 12 2021 г., 15:28
--

DROP TABLE IF EXISTS `users_lf`;
CREATE TABLE `users_lf` (
  `user_id` int(10) NOT NULL,
  `email` varchar(90) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `pass` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `role_id` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users_lf`
--

INSERT INTO `users_lf` (`user_id`, `email`, `pass`, `role_id`) VALUES
(1, '1@mail.ru', '$2y$10$SSXH49vD7vdB5R5nWePlJe9g13D02Uvazjx7cqC5kCx14PqEbbALW', 3);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`account_id`),
  ADD KEY `fk2_user_id` (`user_id`);

--
-- Индексы таблицы `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cashflow`
--
ALTER TABLE `cashflow`
  ADD PRIMARY KEY (`cf_id`) USING BTREE;

--
-- Индексы таблицы `cashflow_names`
--
ALTER TABLE `cashflow_names`
  ADD PRIMARY KEY (`cf_name_id`),
  ADD KEY `fk1_cf_id` (`cf_id`) USING BTREE,
  ADD KEY `fk1_user_id` (`user_id`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Индексы таблицы `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `fk_account_id` (`account_id`),
  ADD KEY `fk_cf_name_id` (`cf_name_id`),
  ADD KEY `fk_cf_id` (`cf_id`) USING BTREE,
  ADD KEY `fk_user_id` (`user_id`) USING BTREE;

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users_lf`
--
ALTER TABLE `users_lf`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_role_id` (`role_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `accounts`
--
ALTER TABLE `accounts`
  MODIFY `account_id` bigint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `cashflow_names`
--
ALTER TABLE `cashflow_names`
  MODIFY `cf_name_id` bigint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `users_lf`
--
ALTER TABLE `users_lf`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `fk2_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_lf` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ограничения внешнего ключа таблицы `cashflow_names`
--
ALTER TABLE `cashflow_names`
  ADD CONSTRAINT `fk1_cf_id` FOREIGN KEY (`cf_id`) REFERENCES `cashflow` (`cf_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk1_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_lf` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ограничения внешнего ключа таблицы `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `fk2_cf_id` FOREIGN KEY (`cf_id`) REFERENCES `cashflow` (`cf_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk3_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_lf` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_account_id` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cf_name_id` FOREIGN KEY (`cf_name_id`) REFERENCES `cashflow_names` (`cf_name_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ограничения внешнего ключа таблицы `users_lf`
--
ALTER TABLE `users_lf`
  ADD CONSTRAINT `fk_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
